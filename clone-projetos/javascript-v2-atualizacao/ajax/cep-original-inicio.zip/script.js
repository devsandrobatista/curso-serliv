const cepInput = document.getElementById("cep");
const logradouroInput = document.getElementById("logradouro");
const bairroInput = document.getElementById("bairro");
const localidadeInput = document.getElementById("localidade");
const ufInput = document.getElementById("uf");
const dialog = document.getElementById("erro-dialog");
const fecharDialogBtn = document.getElementById("fechar-dialog");

/* ***
No vídeo eu errei o id "fechar-dialog", mas depois corrigi. Nesse arquivo a const fecharDialogBtn já está correta

*/
